#!/usr/bin/env bash
# Deploys the Swarmchestrate k3s Metrics Gateway on host A (OptimusDB) and checks it.
# Usage (on host A, in the folder with hostA-gateway.yaml):  bash deploy-hostA.sh
set -euo pipefail
F="$(dirname "$0")/hostA-gateway.yaml"
K="sudo k3s kubectl"
[ -f "$F" ] || { echo "hostA-gateway.yaml not found next to this script"; exit 1; }

echo "== 1/4 pre-checks"
$K get crd ingressroutes.traefik.io >/dev/null && echo "traefik CRDs ok"
$K -n kube-system get deploy metrics-server >/dev/null && echo "metrics-server ok"

echo "== 2/4 deploy (k3s auto-deploy folder)"
sudo cp "$F" /var/lib/rancher/k3s/server/manifests/hostA-gateway.yaml
for i in $(seq 1 30); do $K get ns swarm-system >/dev/null 2>&1 && break; sleep 2; done
$K -n swarm-system rollout status deploy/swch-metrics-gateway --timeout=180s

echo "== 3/4 checks"
KEY=$(grep ' API_KEY:' "$F" | awk '{print $2}')
sleep 3
echo -n "health via Traefik :80   -> "; curl -s http://localhost/swch-metrics/health; echo
echo -n "OptimusDB pods (usage)   -> "; curl -s -H "X-API-Key: $KEY" "http://localhost/swch-metrics/pods/usage?namespace=optimusddc" | head -c 300; echo
echo -n "auth enforced (no key)   -> "; curl -s -o /dev/null -w "%{http_code} (expect 401)\n" http://localhost/swch-metrics/pods/usage
echo -n "OptimusDB route intact   -> "; curl -s -o /dev/null -w "%{http_code}\n" http://localhost/swarmkb/agent/status
for i in $(seq 1 20); do $K -n swarm-system get cm swch-metrics-topology >/dev/null 2>&1 && break; sleep 3; done
$K -n swarm-system get cm swch-metrics-topology

echo "== 4/4 done. From host B this must also work:"
echo "   curl -s http://193.225.250.240/swch-metrics/health"
