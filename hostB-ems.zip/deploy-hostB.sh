#!/usr/bin/env bash
# Adds the Swarmchestrate metrics client as a sidecar of EMS on host B and checks it.
# Usage (on host B, in the folder with hostB-ems.yaml and hostB-ems-sidecar-patch.yaml):  bash deploy-hostB.sh
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
K="sudo k3s kubectl"; NS=default; EMS=emsserver-ems-server
GW=http://193.225.250.240/swch-metrics
KEY=$(grep ' API_KEY:' "$DIR/hostB-ems.yaml" | awk '{print $2}')
die() { echo "  ✗ $1"; echo "STOPPED – nothing on EMS was changed after this point."; exit 1; }

echo "== 1/5 pre-checks"
$K -n $NS get deploy $EMS >/dev/null 2>&1 && echo "  ✓ EMS deployment $NS/$EMS found" || die "EMS deployment $EMS not found in namespace $NS (check: $K get deploy -A | grep ems)"
$K get crd ingressroutes.traefik.io >/dev/null 2>&1 && echo "  ✓ Traefik CRDs present" || die "Traefik IngressRoute CRD missing"
$K get storageclass 2>/dev/null | grep -q "(default)" && echo "  ✓ default StorageClass present" || die "no default StorageClass (needed for the client's volume)"
sudo k3s crictl pull ghcr.io/georgegeorgakakos/k3s-metrics-gateway:0.1.0 >/dev/null 2>&1 && echo "  ✓ image available" || die "cannot pull the image"
H=$(curl -s --max-time 10 "$GW/health"); echo "$H" | grep -q '"ok"' && echo "  ✓ gateway on host A reachable: $H" || die "host B cannot reach $GW/health (port 80 to host A)"
C=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 -H "X-API-Key: $KEY" "$GW/nodes/usage"); [ "$C" = 200 ] && echo "  ✓ API key accepted by host A" || die "API key rejected by host A (HTTP $C)"

echo "== 2/5 client resources (EMS untouched)"
$K apply -f "$DIR/hostB-ems.yaml" || die "apply failed"

echo "== 3/5 attach sidecar to EMS (EMS restarts once)"
if $K -n $NS get deploy $EMS -o jsonpath='{.spec.template.spec.containers[*].name}' | grep -qw swch-metrics-client; then
  echo "  ✓ sidecar already attached – skipping patch"
else
  $K -n $NS patch deployment $EMS --patch-file "$DIR/hostB-ems-sidecar-patch.yaml" || die "patch failed"
fi

echo "== 4/5 waiting for EMS rollout (old EMS pod keeps running until the new one is ready)"
$K -n $NS rollout status deploy/$EMS --timeout=300s || { echo "  ✗ rollout not finished – see: $K -n $NS describe pod -l app.kubernetes.io/name=ems-server"; exit 1; }

echo "== 5/5 checks"
sleep 20
bash "$DIR/check-hostB.sh"
