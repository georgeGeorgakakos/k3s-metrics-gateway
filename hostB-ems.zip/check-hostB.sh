#!/usr/bin/env bash
# Health report for the EMS metrics sidecar on host B.
# Usage (on host B, next to hostB-ems.yaml):  bash check-hostB.sh
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
K="${K:-sudo k3s kubectl}"; NS=default; EMS=emsserver-ems-server
UI="${UI:-http://localhost/swch-metrics-ui}"
PW="${PW:-$(grep ' UI_PASSWORD:' "$DIR/hostB-ems.yaml" 2>/dev/null | awk '{print $2}')}"
ok()  { printf "  \033[32m✓\033[0m %s\n" "$1"; }
bad() { printf "  \033[31m✗\033[0m %s\n" "$1"; FAIL=1; }
FAIL=0

echo "=== DEPLOYMENT ==================================================="
if [ "${SKIP_K8S:-0}" != 1 ]; then
  CS=$($K -n $NS get deploy $EMS -o jsonpath='{.spec.template.spec.containers[*].name}' 2>/dev/null)
  echo "$CS" | grep -qw swch-metrics-client && ok "EMS deployment has containers: $CS" || bad "sidecar not in EMS deployment ($CS)"
  R=$($K -n $NS get deploy $EMS -o jsonpath='{.status.readyReplicas}/{.spec.replicas}' 2>/dev/null)
  [ "$R" = "1/1" ] && ok "EMS deployment ready ($R)" || bad "EMS deployment not ready (${R:-?})"
  P=$($K -n $NS get pod -l app.kubernetes.io/name=ems-server -o jsonpath='{range .items[*]}{.metadata.name} {.status.containerStatuses[*].ready}{"\n"}{end}' 2>/dev/null | head -1)
  echo "$P" | grep -q "true true" && ok "EMS pod: $P (both containers ready)" || bad "EMS pod containers: ${P:-none}"
  $K -n $NS get pvc swch-metrics-client-data -o jsonpath='{.status.phase}' 2>/dev/null | grep -q Bound && ok "client volume (PVC) bound" || bad "client volume (PVC) not bound"
  EP=$($K -n $NS get endpoints swch-metrics-client-ui -o jsonpath='{.subsets[*].addresses[*].ip}' 2>/dev/null)
  [ -n "$EP" ] && ok "UI service has endpoint(s): $EP" || bad "UI service has no endpoints"
  $K -n $NS get ingressroute swch-metrics-client-ui >/dev/null 2>&1 && ok "Traefik route /swch-metrics-ui present" || bad "Traefik route missing"
  L=$($K -n $NS logs deploy/$EMS -c swch-metrics-client --since=15m 2>/dev/null)
  echo "$L" | grep -q "connected to EMS broker" && ok "sidecar connected to the EMS broker (localhost:61610)" || bad "no 'connected to EMS broker' in sidecar logs"
  E=$(echo "$L" | grep -ciE "traceback|error")
  [ "${E:-0}" = 0 ] && ok "no errors in sidecar logs (last 15 min)" || bad "$E error lines → $K -n $NS logs deploy/$EMS -c swch-metrics-client"
fi

echo "=== UI (through Traefik, port 80) ================================"
C=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 -u "admin:$PW" "$UI/")
[ "$C" = 200 ] && ok "UI page answers at $UI/ (login admin)" || bad "UI page returned $C"
C=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "$UI/api/status")
[ "$C" = 401 ] && ok "UI API protected (401 without password)" || bad "expected 401 without password, got $C"

echo
UI="$UI" PW="$PW" python3 - <<'PY'
import base64, json, os, urllib.request
UI, PW = os.environ["UI"], os.environ["PW"]
auth = "Basic " + base64.b64encode(f"admin:{PW}".encode()).decode()
def get(p):
    try:
        return json.load(urllib.request.urlopen(urllib.request.Request(UI + p, headers={"Authorization": auth}), timeout=15))
    except Exception as e:
        print(f"  (could not read {p}: {e})"); return None
s = get("/api/status")
if not s:
    raise SystemExit(0)
mark = lambda b: "✓" if b else "✗"
print("=== CLIENT STATUS ================================================")
print(f"  {mark(s['gateway']['ok'])} gateway on host A: {s['gateway']['url']}")
for k in s["sinks"]:
    print(f"  {mark(k['enabled'] and not k['last_error'] and k['connected'] is not False)} sink {k['id']} ({k['type']}): "
          f"sent={k['sent']} errors={k['errors']} {'connected' if k['connected'] else ''} {k['last_error'] or ''}")
print(f"  samples in the last minute: {s['samples_last_minute']}   total: {s['total_samples']}   series: {s['series']}")
print("\n=== COLLECTORS ===================================================")
print(f"  {'ID':<18}{'TYPE':<16}{'EVERY':<8}{'RUNS':<6}{'LAST':<7}STATUS")
for c in s["collectors"]:
    print(f"  {c['id']:<18}{c['type']:<16}{str(int(c['interval_s']))+'s':<8}{c['runs']:<6}{c['last_count']:<7}{c['status']} {c['last_error'] or ''}")
t = s.get("topology") or {}
if t:
    sm = t.get("summary", {})
    print(f"\n=== TOPOLOGY RECEIVED FROM HOST A ================================\n  swarm={t.get('swarm_id')}  nodes={sm.get('nodes')} ready={sm.get('ready')}  hash={t.get('hash')}")
print("\n=== LATEST VALUES SENT TO EMS (sample) ===========================")
for x in (get("/api/samples?limit=12") or []):
    print(f"  {x['metric']:<42} {str(x.get('instance') or ''):<36} {x['value']}")
PY

echo
[ $FAIL = 0 ] && echo "RESULT: sidecar deployed and working ✓   UI: http://193.225.251.34/swch-metrics-ui/  (admin / UI_PASSWORD in hostB-ems.yaml)" || echo "RESULT: some checks failed ✗ (see above)"
